import psycopg2
import configparser
from tabulate import tabulate
import logging
import os
import csv
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read database configuration from Config_ML.ini file
config = configparser.ConfigParser()
config.read('Config_ML.ini')

# Database connection details
db_config = config['postgresql']
host = db_config['host']
port = db_config['port']
database = db_config['database']
user = db_config['user']
password = db_config['password']

def list_schemas():
    """Lists all schemas available in the PostgreSQL database."""
    schemas = []

    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to fetch all schemas
        query = "SELECT schema_name FROM information_schema.schemata ORDER BY schema_name"

        # Execute the query
        cur.execute(query)

        # Fetch all schemas
        rows = cur.fetchall()
        schemas = [row[0] for row in rows]  # Extract schema names

        # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

    except Exception as e:
        logging.error(f"Error connecting or fetching schemas: {e}")

    return schemas

def select_schema():
    """Prompts the user to select a schema from the list of available schemas."""
    schemas = list_schemas()

    if not schemas:
        logging.warning("No schemas found in the database.")
        return None

    print("Available Schemas:")
    for idx, schema in enumerate(schemas, start=1):
        print(f"{idx}. {schema}")

    while True:
        try:
            choice = int(input("Enter the number corresponding to the schema to use: ").strip())
            if 1 <= choice <= len(schemas):
                selected_schema = schemas[choice - 1]
                logging.info(f"Selected schema: {selected_schema}")
                return selected_schema
            else:
                print("Invalid selection. Please enter a valid number.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def list_tables(schema):
    """Lists all tables in the specified schema, formatted in a tabular format."""
    tables = []

    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to fetch all table names in the specified schema
        query = f"""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = '{schema}'
            AND table_type = 'BASE TABLE'
            ORDER BY table_name
        """

        # Execute the query
        cur.execute(query)

        # Fetch all table names
        rows = cur.fetchall()
        tables = [row[0] for row in rows]  # Extract table names

        # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

    except Exception as e:
        logging.error(f"Error connecting or fetching tables: {e}")

    # Print tables using tabulate
    if tables:
        table_data = [[idx + 1, table] for idx, table in enumerate(tables)]
        headers = ["Number", "Table Name"]
        print(tabulate(table_data, headers=headers, tablefmt="grid"))

    return tables


def select_table(schema):
    """Prompts the user to select a table from the list of available tables in the specified schema."""
    tables = list_tables(schema)

    if not tables:
        logging.warning("No tables found in the selected schema.")
        return None

    #print("Available Tables:")
    #for idx, table in enumerate(tables, start=1):
    #    print(f"{idx}. {table}")

    while True:
        try:
            choice = int(input("Enter the number corresponding to the table to operate on: ").strip())
            if 1 <= choice <= len(tables):
                selected_table = tables[choice - 1]
                logging.info(f"Selected table: {selected_table}")
                return selected_table
            else:
                print("Invalid selection. Please enter a valid number.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def list_functions(schema):
    """Lists all functions in the specified schema."""
    functions = []

    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to fetch all function names in the specified schema
        query = f"""
            SELECT routine_name
            FROM information_schema.routines
            WHERE routine_schema = '{schema}'
            AND routine_type = 'FUNCTION'
            ORDER BY routine_name
        """

        # Execute the query
        cur.execute(query)

        # Fetch all function names
        rows = cur.fetchall()
        functions = [row[0] for row in rows]  # Extract function names

        # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

    except Exception as e:
        logging.error(f"Error connecting or fetching functions: {e}")

    return functions

def select_function(schema):
    """Prompts the user to select a function from the list of available functions in the specified schema."""
    functions = list_functions(schema)

    if not functions:
        logging.warning("No functions found in the selected schema.")
        return None

    print("Available Functions:")
    for idx, function in enumerate(functions, start=1):
        print(f"{idx}. {function}")

    while True:
        try:
            choice = int(input("Enter the number corresponding to the function to operate on: ").strip())
            if 1 <= choice <= len(functions):
                selected_function = functions[choice - 1]
                logging.info(f"Selected function: {selected_function}")

                # Fetch and log function definition
                function_definition = fetch_function_definition(schema, selected_function)
                if function_definition:
                    print("\nFunction Definition:")
                    print(function_definition)

                    # Ask to save function definition
                    save_choice = input("Do you want to save this function definition to a file? (y/n): ").strip().lower()
                    if save_choice == 'y':
                        save_function_definition(selected_function, function_definition)

                return selected_function
            else:
                print("Invalid selection. Please enter a valid number.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def fetch_function_definition(schema, function_name):
    """Fetches the SQL definition of the selected function."""
    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to fetch function definition
        query = f"""
            SELECT pg_get_functiondef((SELECT oid 
                                       FROM pg_proc 
                                       WHERE proname = '{function_name}'
                                       AND pronamespace = (
                                           SELECT oid
                                           FROM pg_namespace
                                           WHERE nspname = '{schema}'
                                       )))
        """

        # Execute the query
        cur.execute(query)

        # Fetch the function definition
        function_definition = cur.fetchone()[0]

        # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

        return function_definition

    except Exception as e:
        logging.error(f"Error fetching function definition for '{function_name}': {e}")
        return None

def save_function_definition(function_name, function_definition):
    """Saves the function definition to a file."""
    try:
        # Generate file name with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{function_name}_{timestamp}.sql"
        filepath = os.path.join(os.getcwd(), filename)

        # Write function definition to file
        with open(filepath, 'w') as file:
            file.write(function_definition)

        logging.info(f"Function definition saved to: {filepath}")

    except Exception as e:
        logging.error(f"Error saving function definition for '{function_name}' to file: {e}")

def list_all_rows(schema, table):
    """Lists all rows in the specified table."""
    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to select all rows from the specified table
        query = f"SELECT * FROM {schema}.{table}"

        # Execute the query
        cur.execute(query)

        # Fetch all rows
        rows = cur.fetchall()

        # Print the rows
        print(f"All rows in table '{table}':")
        for row in rows:
            print(row)

        # Close the cursor and the connection
         # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

    except Exception as e:
        logging.error(f"Error connecting or fetching rows from table '{table}': {e}")

def export_table_to_csv(schema, table):
    """Exports the specified table to a CSV file."""
    try:
        # Establish the connection
        logging.info(f"Connecting to PostgreSQL database '{database}' on {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        logging.info("Connected!")

        # Create a cursor object
        cur = conn.cursor()

        # Query to select all rows from the specified table
        query = f"SELECT * FROM {schema}.{table}"

        # Execute the query
        cur.execute(query)

        # Fetch all rows
        rows = cur.fetchall()

        # Generate CSV file name with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{table}_{timestamp}.csv"
        filepath = os.path.join(os.getcwd(), filename)

        # Write rows to CSV file
        with open(filepath, 'w', newline='') as file:
            csv_writer = csv.writer(file)
            csv_writer.writerow([desc[0] for desc in cur.description])  # Write header
            csv_writer.writerows(rows)  # Write rows

        logging.info(f"Table '{table}' exported to CSV file: {filepath}")

        # Close the cursor and the connection
        cur.close()
        conn.close()
        logging.info("Connection closed.")

    except Exception as e:
        logging.error(f"Error exporting table '{table}' to CSV: {e}")

if __name__ == "__main__":
    try:
        selected_schema = select_schema()

        while True:
            try:
                operation_choice = int(input(
                    "\nSelect operation:\n"
                    "1. Table Operations\n"
                    "2. Function Operations\n"
                    "3. Exit\n"
                    "Enter operation number: ").strip())

                if operation_choice == 1:
                    selected_table = select_table(selected_schema)

                    if selected_table:
                        print(f"Selected table: {selected_table}")

                        while True:
                            try:
                                table_operation_choice = int(input(
                                    "\nSelect operation:\n"
                                    "1. List all rows in the table\n"
                                    "2. Export table to CSV\n"
                                    "3. Both operations\n"
                                    "4. Return to Schema/Operation selection\n"
                                    "5. Exit\n"
                                    "Enter operation number: ").strip())

                                if table_operation_choice == 1:
                                    list_all_rows(selected_schema, selected_table)
                                elif table_operation_choice == 2:
                                    export_table_to_csv(selected_schema, selected_table)
                                elif table_operation_choice == 3:
                                    list_all_rows(selected_schema, selected_table)
                                    export_table_to_csv(selected_schema, selected_table)
                                elif table_operation_choice == 4:
                                    break
                                elif table_operation_choice == 5:
                                    logging.info("Exiting program...")
                                    exit()
                                else:
                                    print("Invalid selection. Please enter a valid number.")

                            except ValueError:
                                print("Invalid input. Please enter a number.")

                elif operation_choice == 2:
                    selected_function = select_function(selected_schema)

                    if selected_function:
                        logging.info(f"Selected function: {selected_function}")
                        # Further operations related to selected function can be added here

                elif operation_choice == 3:
                    logging.info("Exiting program...")
                    break

                else:
                    print("Invalid selection. Please enter a valid number.")

            except ValueError:
                print("Invalid input. Please enter a number.")

    except KeyboardInterrupt:
        logging.info("Program interrupted. Exiting...")
    except Exception as e:
        logging.error(f"Unexpected error occurred: {e}")

