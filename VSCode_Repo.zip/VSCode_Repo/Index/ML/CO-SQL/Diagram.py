from graphviz import Digraph

# Data for the journeys, tables, and columns
data = [
    ('TestDrive', 'test_drive', 'user_id'),
    ('TestDrive', 'cart', 'cart_id'),
    ('TestDrive', 'crm_lead', 'source, source_id'),
    ('RFQ (RFI (called in MY\\TH))', 'customer_rfq', 'user_id'),
    ('RFQ (RFI (called in MY\\TH))', 'user_docs', 'source_id'),
    ('RFQ (RFI (called in MY\\TH))', 'cart', 'cart_id'),
    ('RFQ (RFI (called in MY\\TH))', 'crm_lead', 'source, source_id'),
    ('RFQ (RFI (called in MY\\TH))', 'trade_in', 'rfq_id'),
    ('oem_kmi', 'oem_kmi', 'user_id'),
    ('oem_kmi', 'crm_lead', 'source, source_id'),
    ('online-exclusive-model/pre-reservation', 'user_docs', 'source_id, user_id'),
    ('online-exclusive-model/pre-reservation', 'cart', 'cart_id'),
    ('online-exclusive-model/pre-reservation', 'customer_buy_now', 'user_id, id'),
    ('online-exclusive-model/pre-reservation', 'pre_booking_payment_txn', 'purchase_id'),
    ('online-exclusive-model/pre-reservation', 'payment_txn', 'purchase_id'),
    ('online-exclusive-model/pre-reservation', 'crm_lead', 'source, source_id'),
    ('online-exclusive-model/pre-reservation', 'order', 'purchase_id'),
    ('pre_booking', 'pre_booking', 'user_id'),
    ('pre_booking', 'pre_booking_customer_details', 'id, pre_booking_cust_id, user_id'),
    ('feedback', 'feedback', 'user_id'),
    ('compare list action', 'compare_list_action', 'user_id'),
    ('audit_user', 'audit_user_master', 'user_id'),
    ('download_specification Not For (TH,AU,MY)', 'download_specification (commented)', 'user_id'),
    ('user_dealer_map', 'user_dealer_map', 'user_id'),
    ('cta', 'cta', 'user_id'),
    ('user_login_failed_details', 'user_login_failed_details', 'user_id'),
    ('user_docs', 'user_docs', 'user_id'),
    ('user_master', 'user_master', 'user_role, id')
]


# Extract unique journey names and sort them alphabetically
journeys = sorted(set(journey for journey, _, _ in data))

# Create a Digraph object with left-to-right direction and size
dot = Digraph(comment='Journey Diagrams')
dot.attr(rankdir='LR', size='10,8')

# Set common graph attributes
dot.attr(nodesep='1.0')  # Adjust node separation
dot.attr(ranksep='1.5')  # Adjust rank separation
dot.attr(margin='0.5')   # Adjust overall page margin

# Set common node attributes
dot.node_attr.update(shape='box', fontname='Helvetica', fontsize='12', penwidth='2', color='black')

# Define subgraphs for each journey with their labels and borders
for journey in journeys:
    with dot.subgraph(name=f'cluster_{journey.replace(" ", "_")}') as j:
        j.attr(label=f'{journey} Journey')
        j.attr(penwidth='2')
        j.attr(rank='same')  # Ensure all subgraphs start from the left
        j.attr(margin='10')  # Adjust margin to prevent overlap with content
        
        # Filter data for current journey
        journey_data = [(table.upper(), columns) for _, table, columns in data if journey in _]
        
        # Add nodes for each table and columns in the current journey
        for table, columns in journey_data:
            j.node(f'{table}_{journey.replace(" ", "_")}', f'{table}\n{columns.replace(", ", "\n")}')
        
        # Add edges if needed (connecting nodes in the order they appear)
        for i in range(len(journey_data) - 1):
            j.edge(f'{journey_data[i][0]}_{journey.replace(" ", "_")}', f'{journey_data[i + 1][0]}_{journey.replace(" ", "_")}', arrowhead='normal')

# Render the diagram to a PDF file
dot.render('JourneyDiagrams', format='pdf')

print("Diagrams created successfully in PDF format!")
