import psycopg2
import pandas as pd
from jinja2 import Template
from datetime import datetime

# Database connection parameters
conn_params = {
    'dbname': 'smoss_TH',
    'user': 'qxz4scs',
    'password': 'Welcome2bmw2023',
    'host': 'localhost',
    'port': '9130'
}

# SQL query to fetch unused indexes excluding primary keys and unique constraints
unused_indexes_query = """
SELECT
    idx.schemaname,
    idx.relname AS table_name,
    idx.indexrelname AS index_name,
    idx.idx_scan AS index_scans,
    idx.idx_tup_read AS index_tuples_read,
    idx.idx_tup_fetch AS index_tuples_fetched,
    tab.seq_scan AS table_seq_scans,
    tab.seq_tup_read AS table_seq_tuples_read,
    tab.n_tup_ins AS table_inserts,
    tab.n_tup_upd AS table_updates,
    tab.n_tup_del AS table_deletes
FROM
    pg_stat_user_indexes idx
JOIN
    pg_stat_user_tables tab
ON
    idx.relid = tab.relid
LEFT JOIN
    pg_constraint con
ON
    con.conrelid = idx.relid
    AND con.conindid = idx.indexrelid
    AND con.contype IN ('p', 'u','f')
WHERE
    idx.idx_scan = 0
    AND con.contype IS NULL
ORDER BY
    idx.schemaname, idx.relname;
"""

# Function to connect to PostgreSQL and fetch data
def fetch_data_from_postgresql(query, conn_params):
    try:
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()
        
        # Execute the SQL query
        cursor.execute(query)
        
        # Fetch all results
        results = cursor.fetchall()
        
        # Get column names from the cursor
        colnames = [desc[0] for desc in cursor.description]
        
        # Close the cursor and connection
        cursor.close()
        conn.close()
        
        # Create a DataFrame from the results
        df = pd.DataFrame(results, columns=colnames)
        
        return df
    
    except psycopg2.Error as e:
        print(f"Error connecting to PostgreSQL or executing query: {e}")
        return None

# Function to generate HTML report
def generate_html_report(df, template_filename, output_filename):
    # Load HTML template
    try:
        with open(template_filename, 'r') as file:
            template_str = file.read()
    except FileNotFoundError:
        print(f"Error: Template file '{template_filename}' not found.")
        return
    
    # Create Jinja2 template object
    template = Template(template_str)
    
    # Convert DataFrame to list of dictionaries (each row as a dictionary)
    data_list = df.to_dict(orient='records')
    
    # Format current datetime
    generated_on = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Render HTML with list of dictionaries for the table and formatted date
    html_output = template.render(data=data_list, generated_on=generated_on)
    
    # Write to HTML file
    try:
        with open(output_filename, 'w') as file:
            file.write(html_output)
        print(f"HTML report generated successfully: {output_filename}")
    except IOError as e:
        print(f"Error writing HTML report: {e}")

# Fetch unused indexes data excluding primary keys and unique constraints
df_unused_indexes = fetch_data_from_postgresql(unused_indexes_query, conn_params)

if df_unused_indexes is not None:
    # Generate HTML report
    generate_html_report(df_unused_indexes, 'report_template1.html', 'unused_indexes_report.html')
else:
    print("No data retrieved from PostgreSQL. Check your query or connection parameters.")
