import pandas as pd
from sqlalchemy import create_engine
import openpyxl
from openpyxl.styles import PatternFill

# Set up PostgreSQL connection
engine = create_engine('postgresql://postgres:postgres@localhost:5432/vanajan')


# Define the schemas
schema_1 = 'smms_customerportal_v2'
schema_2 = 'smms_customerportal_v2'

# Query to get the list of tables in each schema
query_tables = """
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = '{}'
"""

# Get table names for both schemas
tables_schema_1 = pd.read_sql_query(query_tables.format(schema_1), engine)['table_name'].tolist()
tables_schema_2 = pd.read_sql_query(query_tables.format(schema_2), engine)['table_name'].tolist()

# Initialize the list to store comparison data and row counts
comparison_data = []
row_count_data = []

# Function to safely quote table names
def quote_table_name(schema, table):
    return f'"{schema}"."{table}"'

# Iterate over the tables (assuming table names are the same in both schemas)
for table in tables_schema_1:
    if table in tables_schema_2:
        # Quote the table names for safe querying
        table_quoted_1 = quote_table_name(schema_1, table)
        table_quoted_2 = quote_table_name(schema_2, table)
        
        # Query row counts from both schemas
        query_count_1 = f'SELECT COUNT(*) FROM {table_quoted_1}'
        query_count_2 = f'SELECT COUNT(*) FROM {table_quoted_2}'
        
        count_1 = pd.read_sql_query(query_count_1, engine).iloc[0, 0]
        count_2 = pd.read_sql_query(query_count_2, engine).iloc[0, 0]
        
        # Compare row counts and append to the first sheet data
        if count_1 == count_2:
            comparison_data.append([f'{schema_1}.{table}', f'{schema_2}.{table}', 'Same number of rows'])
        else:
            comparison_data.append([f'{schema_1}.{table}', f'{schema_2}.{table}', 'Different row counts'])
        
        # Add the row count data for the second sheet
        row_count_data.append([f'{schema_1}.{table}', count_1, f'{schema_2}.{table}', count_2])

# Create DataFrames from the comparison data and row counts
df_comparison = pd.DataFrame(comparison_data, columns=[f'Table from {schema_1}', f'Table from {schema_2}', 'Row Count Comparison'])
df_row_counts = pd.DataFrame(row_count_data, columns=[f'Table from {schema_1}', f'Row Count {schema_1}', f'Table from {schema_2}', f'Row Count {schema_2}'])

# Save the result to an Excel file with two sheets
file_path = r'C:\temp\comparison_report_excel_customer.xlsx'
with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
    df_comparison.to_excel(writer, sheet_name='Comparison', index=False)
    df_row_counts.to_excel(writer, sheet_name='Row Counts', index=False)

# Load the Excel file to apply formatting for 0 row counts and differences
wb = openpyxl.load_workbook(file_path)
ws = wb['Row Counts']

# Define the fill colors for highlighting
highlight_fill_red = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')  # Red for discrepancies

# Iterate over the rows to apply formatting
for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=4):
    count_1_cell = row[1]
    count_2_cell = row[3]
    
    # Convert cell values to integers or handle None
    count_1 = count_1_cell.value if count_1_cell.value is not None else 0
    count_2 = count_2_cell.value if count_2_cell.value is not None else 0
    
    # Ensure values are integers
    count_1 = int(count_1)
    count_2 = int(count_2)

    # Highlight the entire row if there is a discrepancy
    if (count_1 > 0 and count_2 == 0) or (count_1 == 0 and count_2 > 0):
        for cell in row:
            cell.fill = highlight_fill_red

# Save the changes to the Excel file
wb.save(file_path)

print(f"Comparison report saved to {file_path}, with highlighted rows based on 0 row conditions.")
