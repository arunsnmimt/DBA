import os
import psycopg2
import pandas as pd
from openpyxl import Workbook

def fetch_table_names(database_name, schema_name, user, password, host, port):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    cursor.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s
    """, (schema_name,))
    table_names = [row[0] for row in cursor.fetchall()]
    cursor.close()
    connection.close()
    return table_names

def fetch_function_names(database_name, schema_name, user, password, host, port):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    cursor.execute("""
        SELECT proname
        FROM pg_proc
        WHERE pronamespace = (
            SELECT oid FROM pg_namespace WHERE nspname = %s
        )
    """, (schema_name,))
    function_names = [row[0] for row in cursor.fetchall()]
    cursor.close()
    connection.close()
    return function_names

def fetch_sequence_names(database_name, schema_name, user, password, host, port):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    cursor.execute("""
        SELECT sequence_name
        FROM information_schema.sequences
        WHERE sequence_schema = %s
    """, (schema_name,))
    sequence_names = [row[0] for row in cursor.fetchall()]
    cursor.close()
    connection.close()
    return sequence_names

def main():
    # First Database details
    database_name1 = "smoss_IN"
    schema_name1 = "smms_customerportal_v2"
    user1 = "qxz4scs"
    password1 = "Welcome2bmw2023"
    host1 = "localhost"
    port1 = 9096

    # Second Database details
    database_name2 = "smoss_in_uat"
    schema_name2 = "smms_customerportal_v2"
    user2 = "qxz4scs"
    password2 = "Welcome2bmw2023"
    host2 = "localhost"
    port2 = 9096

    # Fetch object names from the first server
    tables1 = fetch_table_names(database_name1, schema_name1, user1, password1, host1, port1)
    functions1 = fetch_function_names(database_name1, schema_name1, user1, password1, host1, port1)
    sequences1 = fetch_sequence_names(database_name1, schema_name1, user1, password1, host1, port1)

    # Fetch object names from the second server
    tables2 = fetch_table_names(database_name2, schema_name2, user2, password2, host2, port2)
    functions2 = fetch_function_names(database_name2, schema_name2, user2, password2, host2, port2)
    sequences2 = fetch_sequence_names(database_name2, schema_name2, user2, password2, host2, port2)

    # Sort names alphabetically
    tables1.sort()
    functions1.sort()
    sequences1.sort()
    tables2.sort()
    functions2.sort()
    sequences2.sort()

    # Create DataFrames for each server's objects
    df_tables1 = pd.DataFrame(tables1, columns=[f'Tables in {database_name1}'])
    df_functions1 = pd.DataFrame(functions1, columns=[f'Functions in {database_name1}'])
    df_sequences1 = pd.DataFrame(sequences1, columns=[f'Sequences in {database_name1}'])

    df_tables2 = pd.DataFrame(tables2, columns=[f'Tables in {database_name2}'])
    df_functions2 = pd.DataFrame(functions2, columns=[f'Functions in {database_name2}'])
    df_sequences2 = pd.DataFrame(sequences2, columns=[f'Sequences in {database_name2}'])

    # Compare object names
    common_tables = set(tables1).intersection(tables2)
    common_functions = set(functions1).intersection(functions2)
    common_sequences = set(sequences1).intersection(sequences2)
    
    tables_only_in_1 = set(tables1) - set(tables2)
    functions_only_in_1 = set(functions1) - set(functions2)
    sequences_only_in_1 = set(sequences1) - set(sequences2)
    
    tables_only_in_2 = set(tables2) - set(tables1)
    functions_only_in_2 = set(functions2) - set(functions1)
    sequences_only_in_2 = set(sequences2) - set(sequences1)

    # Sort object names alphabetically
    common_tables = sorted(list(common_tables))
    common_functions = sorted(list(common_functions))
    common_sequences = sorted(list(common_sequences))
    
    tables_only_in_1 = sorted(list(tables_only_in_1))
    functions_only_in_1 = sorted(list(functions_only_in_1))
    sequences_only_in_1 = sorted(list(sequences_only_in_1))
    
    tables_only_in_2 = sorted(list(tables_only_in_2))
    functions_only_in_2 = sorted(list(functions_only_in_2))
    sequences_only_in_2 = sorted(list(sequences_only_in_2))

    # Create DataFrames for the comparison results
    df_common_tables = pd.DataFrame(common_tables, columns=['Common Tables'])
    df_common_functions = pd.DataFrame(common_functions, columns=['Common Functions'])
    df_common_sequences = pd.DataFrame(common_sequences, columns=['Common Sequences'])
    
    df_only_in_server1_tables = pd.DataFrame(tables_only_in_1, columns=[f'Tables Only in {database_name1}'])
    df_only_in_server1_functions = pd.DataFrame(functions_only_in_1, columns=[f'Functions Only in {database_name1}'])
    df_only_in_server1_sequences = pd.DataFrame(sequences_only_in_1, columns=[f'Sequences Only in {database_name1}'])
    
    df_only_in_server2_tables = pd.DataFrame(tables_only_in_2, columns=[f'Tables Only in {database_name2}'])
    df_only_in_server2_functions = pd.DataFrame(functions_only_in_2, columns=[f'Functions Only in {database_name2}'])
    df_only_in_server2_sequences = pd.DataFrame(sequences_only_in_2, columns=[f'Sequences Only in {database_name2}'])

    # Specify the directory path
    backup_dir = "C:\\backup"

    # Check if the directory exists, if not create it
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Specify the file path
    file_path = os.path.join(backup_dir, 'object_comparison.xlsx')

    # Write to Excel
    with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
        # Write each DataFrame to a separate sheet
        df_common_tables.to_excel(writer, sheet_name='Common Tables', index=False)
        df_common_functions.to_excel(writer, sheet_name='Common Functions', index=False)
        df_common_sequences.to_excel(writer, sheet_name='Common Sequences', index=False)
        
        df_only_in_server1_tables.to_excel(writer, sheet_name=f'Tables Only in {database_name1}', index=False)
        df_only_in_server1_functions.to_excel(writer, sheet_name=f'Functions Only in {database_name1}', index=False)
        df_only_in_server1_sequences.to_excel(writer, sheet_name=f'Sequences Only in {database_name1}', index=False)
        
        df_only_in_server2_tables.to_excel(writer, sheet_name=f'Tables Only in {database_name2}', index=False)
        df_only_in_server2_functions.to_excel(writer, sheet_name=f'Functions Only in {database_name2}', index=False)
        df_only_in_server2_sequences.to_excel(writer, sheet_name=f'Sequences Only in {database_name2}', index=False)

if __name__ == "__main__":
    main()
