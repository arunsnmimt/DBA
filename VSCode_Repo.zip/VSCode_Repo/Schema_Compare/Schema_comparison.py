import psycopg2
import pandas as pd

# Connect to your PostgreSQL database
conn = psycopg2.connect(
    host="localhost",
    database="smoss_AU",
    user="qxz4scs",
    password="Welcome2bmw2023",
    port="9094"
)

# Define the PL/pgSQL script to execute
plpgsql_script = """
DO $$
DECLARE
    prod_table_name TEXT;
    uat_table_name TEXT;
    prod_query TEXT;
    uat_query TEXT;
    prod_exists BOOLEAN;
    staging_exists BOOLEAN;
BEGIN
    -- Loop through each table in the schema
    FOR prod_table_name IN
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'bmw_admin_au_onlinesales' -- Adjust schema name
    LOOP
        -- Check if production table exists
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = 'bmw_admin_au_onlinesales' -- Adjust schema name
            AND table_name = prod_table_name
        ) INTO prod_exists;
        
        -- Check if staging table exists
        SELECT EXISTS (
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = 'your_schema_name' -- Adjust schema name
            AND table_name = prod_table_name || '_staging'
        ) INTO staging_exists;
        
        -- If production table exists, proceed with comparison
        IF prod_exists THEN
            IF staging_exists THEN
                prod_query := 'SELECT ''' || prod_table_name || ''' AS table_name, column_name, data_type FROM information_schema.columns WHERE table_name = ''' || prod_table_name || '''';
                uat_query := 'SELECT ''' || prod_table_name || ''' AS table_name, column_name, data_type FROM information_schema.columns WHERE table_name = ''' || prod_table_name || '_staging''';
                
                -- Execute the queries and output the results
                RAISE NOTICE 'Comparing table: %', prod_table_name;
                EXECUTE prod_query;
                EXECUTE uat_query;
            ELSE
                -- If staging table doesn't exist, output a message
                RAISE NOTICE 'Staging table missing for table: %', prod_table_name;
            END IF;
        ELSE
            -- If production table doesn't exist, output a message
            RAISE NOTICE 'Production table missing: %', prod_table_name;
        END IF;
    END LOOP;
END $$;
"""

# Execute the PL/pgSQL script
cur = conn.cursor()
cur.execute(plpgsql_script)

# Fetch all notices (including our custom messages)
notices = cur.fetchall()
for notice in notices:
    print(notice[0])

# Close the cursor and connection
cur.close()
conn.close()
