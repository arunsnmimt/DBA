import os
import psycopg2
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill

def fetch_table_names(database_name, table_name, user, password, host, port):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    cursor.execute(f"""
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
    """)
    table_structure = cursor.fetchall()
    cursor.close()
    connection.close()
    return table_structure

def main():
    # First Database details
    database_name1 = "smoss_IN"
    schema_name1 = "smms_customerportal_v2"
    user1 = "qxz4scs"
    password1 = "Welcome2bmw2023"
    host1 = "localhost"
    port1 = 9096

    # Second Database details
    database_name2 = "smoss_in_uat"
    schema_name2 = "smms_customerportal_v2"
    user2 = "qxz4scs"
    password2 = "Welcome2bmw2023"
    host2 = "localhost"
    port2 = 9096

    # Fetch table names from the first server
    tables1 = fetch_table_names(database_name1, schema_name1, user1, password1, host1, port1)

    # Fetch table names from the second server
    tables2 = fetch_table_names(database_name2, schema_name2, user2, password2, host2, port2)

    # Sort table names alphabetically
    tables1.sort()
    tables2.sort()

    # Create DataFrames for each server's tables
    df_tables1 = pd.DataFrame(tables1, columns=[f'Tables in {database_name1}'])
    df_tables2 = pd.DataFrame(tables2, columns=[f'Tables in {database_name2}'])

    # Compare table names
    common_tables = set(tables1).intersection(tables2)
    tables_only_in_1 = set(tables1) - set(tables2)
    tables_only_in_2 = set(tables2) - set(tables1)

    # Sort common tables alphabetically
    common_tables = sorted(list(common_tables))
    tables_only_in_1 = sorted(list(tables_only_in_1))
    tables_only_in_2 = sorted(list(tables_only_in_2))

    # Create DataFrames for the comparison results
    df_common_tables = pd.DataFrame(common_tables, columns=['Common Tables'])
    df_only_in_server1 = pd.DataFrame(tables_only_in_1, columns=[f'Tables Only in {database_name1}'])
    df_only_in_server2 = pd.DataFrame(tables_only_in_2, columns=[f'Tables Only in {database_name2}'])

    # Specify the directory path
    backup_dir = "C:\\backup"

    # Check if the directory exists, if not create it
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Specify the file path
    file_path = os.path.join(backup_dir, 'table_comparison.xlsx')

    # Write to Excel
    with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
        # Write each DataFrame to a separate sheet
        df_tables1.to_excel(writer, sheet_name=f'Tables in {database_name1}', index=False)
        df_tables2.to_excel(writer, sheet_name=f'Tables in {database_name2}', index=False)
        df_common_tables.to_excel(writer, sheet_name='Common Tables', index=False)
        df_only_in_server1.to_excel(writer, sheet_name=f'Tables Only in {database_name1}', index=False)
        df_only_in_server2.to_excel(writer, sheet_name=f'Tables Only in {database_name2}', index=False)
        
        # Get the workbook
        wb = writer.book

        # Set tab colors for all sheets
        tab_color = 'FF5733'  # You can change this color code as desired
        for sheet in wb.sheetnames:
            sheet_obj = wb[sheet]
            sheet_obj.sheet_properties.tabColor = tab_color

        # Compare table structures
        for table_name in common_tables:
            structure1 = fetch_table_structure(database_name1, table_name, user1, password1, host1, port1)
            structure2 = fetch_table_structure(database_name2, table_name, user2, password2, host2, port2)
            
            df_structure1 = pd.DataFrame(structure1, columns=[f'{database_name1} Column Name', f'{database_name1} Data Type'])
            df_structure2 = pd.DataFrame(structure2, columns=[f'{database_name2} Column Name', f'{database_name2} Data Type'])
            
            df_structure1.to_excel(writer, sheet_name=f'{table_name} Structure in {database_name1}', index=False)
            df_structure2.to_excel(writer, sheet_name=f'{table_name} Structure in {database_name2}', index=False)

if __name__ == "__main__":
    main()
