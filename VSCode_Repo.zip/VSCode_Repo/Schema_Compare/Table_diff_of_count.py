import pandas as pd
from sqlalchemy import create_engine
import openpyxl
from openpyxl.styles import PatternFill

# Set up PostgreSQL connection
engine = create_engine('postgresql://postgres:postgres@localhost:5432/vanajan')

# Define the schemas
schema_1 = 'bmw_admin_nz'
schema_2 = 'bmw_admin_nz_n'

# Query to get the list of tables in each schema
query_tables = """
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = '{}'
"""

# Get table names for both schemas
tables_schema_1 = pd.read_sql_query(query_tables.format(schema_1), engine)['table_name'].tolist()
tables_schema_2 = pd.read_sql_query(query_tables.format(schema_2), engine)['table_name'].tolist()

# Initialize the list to store comparison data and row counts
comparison_data = []
row_count_data = []

# Iterate over the tables (assuming table names are the same in both schemas)
for table in tables_schema_1:
    if table in tables_schema_2:
        # Query row counts from both schemas
        query_count_1 = f"SELECT COUNT(*) FROM {schema_1}.{table}"
        query_count_2 = f"SELECT COUNT(*) FROM {schema_2}.{table}"
        
        count_1 = pd.read_sql_query(query_count_1, engine).iloc[0, 0]
        count_2 = pd.read_sql_query(query_count_2, engine).iloc[0, 0]
        
        # Compare row counts and append to the first sheet data
        if count_1 == count_2:
            comparison_data.append([f'{schema_1}.{table}', f'{schema_2}.{table}', 'Same number of rows'])
        else:
            comparison_data.append([f'{schema_1}.{table}', f'{schema_2}.{table}', 'Different row counts'])
        
        # Add the row count data for the second sheet
        row_count_data.append([f'{schema_1}.{table}', count_1, f'{schema_2}.{table}', count_2])

# Create DataFrames from the comparison data and row counts
df_comparison = pd.DataFrame(comparison_data, columns=[f'Table from {schema_1}', f'Table from {schema_2}', 'Row Count Comparison'])
df_row_counts = pd.DataFrame(row_count_data, columns=[f'Table from {schema_1}', f'Row Count {schema_1}', f'Table from {schema_2}', f'Row Count {schema_2}'])

# Save the result to an Excel file with two sheets
file_path = r'C:\temp\comparison_report_excel.xlsx'
with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
    df_comparison.to_excel(writer, sheet_name='Comparison', index=False)
    df_row_counts.to_excel(writer, sheet_name='Row Counts', index=False)

# Load the Excel file to apply formatting for 0 row counts and differences
wb = openpyxl.load_workbook(file_path)
ws = wb['Row Counts']

# Define the fill colors for highlighting
highlight_fill_yellow = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')  # Yellow for both 0 rows
highlight_fill_red = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')  # Red for one table 0, other > 0

# Iterate over the row count sheet and highlight based on conditions
for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=2, max_col=4, values_only=False):
    count_1 = row[0].value
    count_2 = row[2].value
    
    if count_1 == 0 and count_2 == 0:
        # Highlight both columns if both counts are 0
        row[0].fill = highlight_fill_yellow
        row[2].fill = highlight_fill_yellow
    elif (count_1 > 0 and count_2 == 0) or (count_1 == 0 and count_2 > 0):
        # Highlight in red if one schema has rows and the other has 0
        row[0].fill = highlight_fill_red if count_1 == 0 else None
        row[2].fill = highlight_fill_red if count_2 == 0 else None

# Save the changes to the Excel file
wb.save(file_path)

print(f"Comparison report saved to {file_path}, with highlighted rows based on 0 row conditions.")
