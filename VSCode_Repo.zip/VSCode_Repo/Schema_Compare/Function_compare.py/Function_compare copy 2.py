import os
import psycopg2
import re
import csv
from datetime import datetime

# Database connection setup (customize this for your PostgreSQL DB)
conn = psycopg2.connect(
    host="localhost",
    port="5432",  # Default PostgreSQL port
    database="smoss_nz",
    user="postgres",
    password="postgres"
)


# Cursor to execute queries
cursor = conn.cursor()

# SQL to fetch function names from schema A
cursor.execute("""
    SELECT routine_name 
    FROM information_schema.routines 
    WHERE routine_type = 'FUNCTION' 
    AND specific_schema = 'bmw_admin_nz'
""")

# Fetch all function names
functions = cursor.fetchall()

# Initialize sets for staging and non-staging functions
staging_functions = set()
non_staging_functions = set()

# Categorize functions based on suffix
for func in functions:
    func_name = func[0]
    if func_name.endswith('_staging'):
        staging_functions.add(func_name)
    else:
        non_staging_functions.add(func_name)

# Directory paths
base_dir = "C:/temp/bmw_admin_nz"
staging_dir = os.path.join(base_dir, "staging")
non_staging_dir = os.path.join(base_dir, "non-staging")

# Create directories if they don't exist
os.makedirs(staging_dir, exist_ok=True)
os.makedirs(non_staging_dir, exist_ok=True)

# Get current timestamp for the report
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
report_path = os.path.join(base_dir, f"function_analysis_report_{timestamp}.csv")

# Function to get the OID of a function by name
def get_function_oid(func_name):
    cursor.execute(f"SELECT oid FROM pg_proc WHERE proname = '{func_name}'")
    return cursor.fetchone()

# Function to extract table, view, or function references from the SQL definition
def extract_references(sql_definition):
    # Regex patterns for matching table, view, and function references
    table_view_pattern = r'(FROM|JOIN)\s+([a-zA-Z0-9_\.]+)'
    function_pattern = r'(\w+)\s*\('  # Matches function names
    
    tables_views = re.findall(table_view_pattern, sql_definition, re.IGNORECASE)
    functions = re.findall(function_pattern, sql_definition)
    
    # Return the list of tables/views and functions found
    return [ref[1] for ref in tables_views], functions

# Function to check if an object (table/view/function) exists in the database
def check_object_existence(obj_name, obj_type='table'):
    if obj_type == 'table':
        cursor.execute(f"SELECT to_regclass('{obj_name}') IS NOT NULL")
    elif obj_type == 'function':
        cursor.execute(f"SELECT EXISTS(SELECT 1 FROM pg_proc WHERE proname = '{obj_name}')")
    return cursor.fetchone()[0]

# CSV header
csv_header = ['Non-Staging Function', 'Staging Function', 'Review']

# Open CSV report
with open(report_path, mode='w', newline='') as report_file:
    writer = csv.writer(report_file)
    writer.writerow(csv_header)

    # Analyze functions
    for staging_func in staging_functions:
        # Corresponding non-staging function
        non_staging_func = staging_func.replace('_staging', '')
        
        # Get OIDs
        non_staging_oid = get_function_oid(non_staging_func)
        staging_oid = get_function_oid(staging_func)
        
        # Initialize review message
        review = []
        
        # If non-staging function exists, check its dependencies
        if non_staging_oid:
            cursor.execute(f"SELECT pg_get_functiondef({non_staging_oid[0]})")
            non_staging_def = cursor.fetchone()[0]
            tables_views, functions = extract_references(non_staging_def)
            
            # Check existence of tables/views
            for obj in tables_views:
                if not check_object_existence(obj, 'table'):
                    review.append(f"Missing table/view: {obj}")
            
            # Check existence of functions
            for func in functions:
                if not check_object_existence(func, 'function'):
                    review.append(f"Missing function: {func}")
        
        # If staging function exists, check its dependencies
        if staging_oid:
            cursor.execute(f"SELECT pg_get_functiondef({staging_oid[0]})")
            staging_def = cursor.fetchone()[0]
            tables_views, functions = extract_references(staging_def)
            
            # Check existence of tables/views
            for obj in tables_views:
                if not check_object_existence(obj, 'table'):
                    review.append(f"Missing table/view: {obj}")
            
            # Check existence of functions
            for func in functions:
                if not check_object_existence(func, 'function'):
                    review.append(f"Missing function: {func}")
        
        # If there is any missing object, write to CSV
        if review:
            writer.writerow([non_staging_func, staging_func, "; ".join(review)])

# Close the cursor and connection
cursor.close()
conn.close()

print(f"Report generated at: {report_path}")
