import os
import psycopg2

# Database connection setup (customize this for your PostgreSQL DB)
conn = psycopg2.connect(
    host="localhost",
    port="5432",  # Default PostgreSQL port
    database="smoss_nz",
    user="postgres",
    password="postgres"
)


# Cursor to execute queries
cursor = conn.cursor()

# SQL to fetch function names from schema A
cursor.execute("""
    SELECT routine_name 
    FROM information_schema.routines 
    WHERE routine_type = 'FUNCTION' 
    AND specific_schema = 'bmw_admin_nz'
""")

# Fetch all function names
functions = cursor.fetchall()

# Initialize sets for staging and non-staging functions
staging_functions = set()
non_staging_functions = set()

# Categorize functions based on suffix
for func in functions:
    func_name = func[0]
    if func_name.endswith('_staging'):
        staging_functions.add(func_name)
    else:
        non_staging_functions.add(func_name)

# Directory paths
base_dir = r"C:\Temp\bmw_admin_nz"
staging_dir = os.path.join(base_dir, "staging")
non_staging_dir = os.path.join(base_dir, "non-staging")

# Create directories if they don't exist
os.makedirs(staging_dir, exist_ok=True)
os.makedirs(non_staging_dir, exist_ok=True)

# Save functions to the appropriate directories
for staging_func in staging_functions:
    # Corresponding non-staging function
    non_staging_func = staging_func.replace('_staging', '')
    
    # If non-staging function exists, save both
    if non_staging_func in non_staging_functions:
        # Fetch and save non-staging function
        cursor.execute(f"SELECT pg_get_functiondef('{non_staging_func}')")
        non_staging_def = cursor.fetchone()[0]
        with open(os.path.join(non_staging_dir, f"{non_staging_func}.sql"), 'w') as f:
            f.write(non_staging_def)
        
        # Fetch and save staging function
        cursor.execute(f"SELECT pg_get_functiondef('{staging_func}')")
        staging_def = cursor.fetchone()[0]
        with open(os.path.join(staging_dir, f"{staging_func}.sql"), 'w') as f:
            f.write(staging_def)

# Close the cursor and connection
cursor.close()
conn.close()
