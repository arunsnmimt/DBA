import os
import psycopg2
import re
import pandas as pd
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

# Database connection setup (customize this for your PostgreSQL DB)
conn = psycopg2.connect(
    host="localhost",
    port="5432",  # Default PostgreSQL port
    database="smoss_nz",
    user="postgres",
    password="postgres"
)

# Cursor to execute queries
cursor = conn.cursor()

# SQL to fetch function names from schema A
cursor.execute("""
    SELECT routine_name 
    FROM information_schema.routines 
    WHERE routine_type = 'FUNCTION' 
    AND specific_schema = 'bmw_admin_nz'
""")

# Fetch all function names
functions = cursor.fetchall()

# Initialize sets for staging and non-staging functions
staging_functions = set()
non_staging_functions = set()

# Categorize functions based on suffix
for func in functions:
    func_name = func[0]
    if func_name.endswith('_staging'):
        staging_functions.add(func_name)
    else:
        non_staging_functions.add(func_name)

# Directory paths
base_dir = "C:/temp/A"
os.makedirs(base_dir, exist_ok=True)

# Get current timestamp for the report
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
excel_file_path = os.path.join(base_dir, f"function_analysis_report_{timestamp}.xlsx")

# Function to get the OID of a function by name
def get_function_oid(func_name):
    cursor.execute(f"SELECT oid FROM pg_proc WHERE proname = '{func_name}'")
    return cursor.fetchone()

# Function to extract schema-prefixed table, view, or function references from the SQL definition
def extract_references(sql_definition):
    # Regex pattern for matching schema-prefixed table, view, and function references
    schema_obj_pattern = r'([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)'  # Matches schema_name.object_name

    # Find all schema-prefixed object references
    objects = re.findall(schema_obj_pattern, sql_definition)
    
    # Return the list of unique schema-prefixed objects that start with bmw_admin_nz
    return list(set([f"{schema}.{obj}" for schema, obj in objects if schema == 'bmw_admin_nz']))

# Create data lists for the main report
main_report_data = []

# Analyze functions for the main report
for staging_func in staging_functions:
    # Corresponding non-staging function
    non_staging_func = staging_func.replace('_staging', '')
    
    # Get OIDs
    non_staging_oid = get_function_oid(non_staging_func)
    staging_oid = get_function_oid(staging_func)
    
    # Initialize references lists
    non_staging_references = set()
    staging_references = set()
    
    # If non-staging function exists, check its dependencies
    if non_staging_oid:
        cursor.execute(f"SELECT pg_get_functiondef({non_staging_oid[0]})")
        non_staging_def = cursor.fetchone()[0]
        objects = extract_references(non_staging_def)
        non_staging_references.update(objects)

    # If staging function exists, check its dependencies
    if staging_oid:
        cursor.execute(f"SELECT pg_get_functiondef({staging_oid[0]})")
        staging_def = cursor.fetchone()[0]
        objects = extract_references(staging_def)
        staging_references.update(objects)

    # Append to main report data
    main_report_data.append([
        non_staging_func, 
        staging_func, 
        "; ".join(sorted(non_staging_references)),  # Sort and join unique non-staging references
        "; ".join(sorted(staging_references))       # Sort and join unique staging references
    ])

# Create a DataFrame from the main report data
main_report_df = pd.DataFrame(main_report_data, columns=['Non-Staging Function', 'Staging Function', 'Non-Staging References', 'Staging References'])

# Create a list for summary report
summary_report_data = []

# Create the function reference summary based on main report data
for _, row in main_report_df.iterrows():
    non_staging_func = row['Non-Staging Function']
    non_staging_refs = row['Non-Staging References'].split('; ')
    staging_refs = row['Staging References'].split('; ')
    
    # Initialize a dictionary to hold correlation
    correlation = {}
    
    # Process non-staging references
    for ns_ref in non_staging_refs:
        # Check for direct correlation or _staging match
        staging_ref = ""
        ns_ref_staging = ns_ref + '_staging'
        
        if ns_ref in staging_refs:
            staging_ref = ns_ref  # Direct match found
        elif ns_ref_staging in staging_refs:
            staging_ref = ns_ref_staging  # Match found with _staging
        
        if staging_ref:
            correlation[ns_ref] = staging_ref
        else:
            correlation[ns_ref] = "No correlation"
    
    # Prepare summary report data
    for ns_ref, staging_ref in correlation.items():
        summary_report_data.append([non_staging_func, ns_ref, staging_ref])

# Create a DataFrame for the summary report
summary_report_df = pd.DataFrame(summary_report_data, columns=['Non-Staging Function', 'Non-Staging References', 'Staging References'])

# Create a Pandas Excel writer using OpenPyXL as the engine
with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
    # Write main report to a sheet
    main_report_df.to_excel(writer, sheet_name='Function Analysis', index=False)
    
    # Write summary report to another sheet
    summary_report_df.to_excel(writer, sheet_name='Function Reference Summary', index=False)

    # Load the workbook and get the active sheet
    workbook = writer.book
    summary_sheet = workbook['Function Reference Summary']
    
    # Define fill styles for highlighting
    fill_no_correlation = PatternFill(start_color="FF9999", end_color="FF9999", fill_type="solid")  # Red fill for no correlation
    fill_same_value = PatternFill(start_color="FFFF99", end_color="FFFF99", fill_type="solid")  # Yellow fill for same value

    # Highlight rows based on conditions
    for row in range(2, len(summary_report_df) + 2):  # Skip header row
        non_staging_ref = summary_sheet.cell(row=row, column=2).value
        staging_ref = summary_sheet.cell(row=row, column=3).value
        
        # Check for no correlation
        if staging_ref == "No correlation":
            for col in range(1, 4):  # Highlight all columns of that row
                summary_sheet.cell(row=row, column=col).fill = fill_no_correlation
        
        # Check if non-staging and staging references are the same
        elif non_staging_ref == staging_ref:
            for col in range(1, 4):  # Highlight all columns of that row
                summary_sheet.cell(row=row, column=col).fill = fill_same_value

# Close the cursor and connection
cursor.close()
conn.close()

print(f"Excel report generated at: {excel_file_path}")
