import os
import psycopg2
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill

def fetch_table_names(database_name, schema_name, user, password, host, port):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    cursor.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s
    """, (schema_name,))
    table_names = [row[0] for row in cursor.fetchall()]
    cursor.close()
    connection.close()
    return table_names

def main():
    # First Database details
    database_name1 = "smoss_nz_one_platform"
    schema_name1 = "smms_customerportal_v2"
    user1 = "qxz4scs"
    password1 = "Welcome2bmw2023"
    host1 = "localhost"
    port1 = 8084

    # Second Database details
    database_name2 = "smoss_nz_qa"
    schema_name2 = "smms_customerportal_v2"
    user2 = "qxz4scs"
    password2 = "Welcome2bmw2023"
    host2 = "localhost"
    port2 = 8084

    # Fetch table names from the first server
    tables1 = fetch_table_names(database_name1, schema_name1, user1, password1, host1, port1)

    # Fetch table names from the second server
    tables2 = fetch_table_names(database_name2, schema_name2, user2, password2, host2, port2)

    # Sort table names alphabetically
    tables1.sort()
    tables2.sort()

    # Create DataFrames for each server's tables
    df_tables1 = pd.DataFrame(tables1, columns=[f'Tables in {database_name1}'])
    df_tables2 = pd.DataFrame(tables2, columns=[f'Tables in {database_name2}'])

    # Compare table names
    common_tables = set(tables1).intersection(tables2)
    tables_only_in_1 = set(tables1) - set(tables2)
    tables_only_in_2 = set(tables2) - set(tables1)

    # Sort common tables alphabetically
    common_tables = sorted(list(common_tables))
    tables_only_in_1 = sorted(list(tables_only_in_1))
    tables_only_in_2 = sorted(list(tables_only_in_2))

    # Create DataFrames for the comparison results
    df_common_tables = pd.DataFrame(common_tables, columns=['Common Tables'])
    df_only_in_server1 = pd.DataFrame(tables_only_in_1, columns=[f'Tables Only in {database_name1}'])
    df_only_in_server2 = pd.DataFrame(tables_only_in_2, columns=[f'Tables Only in {database_name2}'])

    # Specify the directory path
    backup_dir = "C:\\backup\\nz"

    # Check if the directory exists, if not create it
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Specify the file path
    file_path = os.path.join(backup_dir, 'table_comparison.xlsx')

    # Write to Excel
    with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
        # Write each DataFrame to a separate sheet
        df_tables1.to_excel(writer, sheet_name=f'Tables in {database_name1}', index=False)
        df_tables2.to_excel(writer, sheet_name=f'Tables in {database_name2}', index=False)
        df_common_tables.to_excel(writer, sheet_name='Common Tables', index=False)
        df_only_in_server1.to_excel(writer, sheet_name=f'Tables Only in {database_name1}', index=False)
        df_only_in_server2.to_excel(writer, sheet_name=f'Tables Only in {database_name2}', index=False)
        
        # Get the workbook
        wb = writer.book

        # Set tab colors
        tab_colors = {f'Tables in {database_name1}': 'FF5733', f'Tables in {database_name2}': '33FF57'}
        for sheet_name, color in tab_colors.items():
            sheet = wb[sheet_name]
            tab_color = color
            sheet.sheet_properties.tabColor = tab_color

if __name__ == "__main__":
    main()
