import os
import psycopg2
import configparser
import pandas as pd
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def fetch_table_info(connection_string, instance_name):
    try:
        conn = psycopg2.connect(connection_string)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                current_database() AS database_name,
                schemaname AS schema_name,
                tablename AS table_name,
                ROUND(pg_relation_size(format('%I.%I', schemaname, tablename)) / (1024.0 * 1024.0), 2) AS table_size_mb,
                ROUND(pg_indexes_size(format('%I.%I', schemaname, tablename)) / (1024.0 * 1024.0), 2) AS indexes_size_mb,
                ROUND(pg_total_relation_size(format('%I.%I', schemaname, tablename)) / (1024.0 * 1024.0), 2) AS total_size_mb,
                (xpath('/row/cnt/text()', query_to_xml(format('SELECT count(*) AS cnt FROM %I.%I', schemaname, tablename), true, true, '')))[1]::text::bigint AS row_count
            FROM
                pg_tables
            WHERE
                schemaname NOT IN ('pg_catalog', 'information_schema') -- Exclude system schemas
                AND schemaname NOT LIKE 'pg_toast'
            ORDER BY
                total_size_mb DESC;
        """)
        table_info = cursor.fetchall()

        # Get column names from cursor description
        column_names = [desc.name for desc in cursor.description]

        cursor.close()
        conn.close()

        return table_info, column_names

    except Exception as e:
        logging.error(f"Error fetching table information for instance '{instance_name}': {e}")
        return None, None

def fetch_table_info_parallel(instance):
    connection_string = instance['connection_string']
    instance_name = instance.get('instance_name', instance.name)
    
    logging.info(f"Fetching table information for instance: {instance_name}")
    
    table_info, column_names = fetch_table_info(connection_string, instance_name)
    
    if table_info is None:
        logging.warning(f"Skipping instance '{instance_name}' due to error.")
        return None
    
    df_instance = pd.DataFrame(table_info, columns=column_names)
    df_instance['Instance'] = instance_name
    return df_instance

def main():
    # Path to the config.ini file
    config_file_path = r'C:\connections\config-non-prod-all-databases.ini'

    # Parse the configuration file
    config = configparser.ConfigParser()
    config.read(config_file_path)

    # Create an empty list to store future instances
    futures = []
    
    # Create a ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=5) as executor:
        # Submit tasks for each instance
        for section in config.sections():
            future = executor.submit(fetch_table_info_parallel, config[section])
            futures.append(future)
    
    # Create an empty DataFrame to store table information
    df = pd.DataFrame()

    # Iterate through completed futures
    for future in as_completed(futures):
        df_instance = future.result()
        if df_instance is not None:
            df = pd.concat([df, df_instance], ignore_index=True)

    # Path to save the Excel file
    output_directory = r"C:\backup"
    output_file = os.path.join(output_directory, "all_databases_tables_info2.xlsx")

    # Ensure the directory exists
    os.makedirs(output_directory, exist_ok=True)

    # Write DataFrame to Excel
    df.to_excel(output_file, index=False)
    logging.info(f"Table information for all databases has been saved to {output_file}")

if __name__ == "__main__":
    main()
