import pg8000
import awswrangler as wr
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# Connect to PostgreSQL RDS
def get_postgres_version():
    try:
        connection = pg8000.connect(
            host='database-2.cxoolvpkjide.ap-south-1.rds.amazonaws.com',
            port=5432,
            database='postgres',
            user='postgres',
            password='Password01!'
        )
        cursor = connection.cursor()
        cursor.execute("SELECT version();")
        postgres_version = cursor.fetchone()[0]
        cursor.close()
        connection.close()
        return postgres_version
    except Exception as error:
        print(f"Error connecting to PostgreSQL: {error}")
        return None

# Send email using Amazon SES with awswrangler
def send_email_ses(subject, body, recipient_email):
    try:
        response = wr.ses.send_email(
            source='arunsnmimt@gmail.com',
            to_addresses=[recipient_email],
            subject=subject,
            body_text=body,
            region='ap-south-1'  # Change to your preferred AWS region
        )
        print("Email sent! Message ID:", response['MessageId'])
    except (NoCredentialsError, PartialCredentialsError) as e:
        print("AWS Credentials Error:", e)
    except Exception as e:
        print(f"Error sending email: {e}")

# Main logic
if __name__ == '__main__':
    postgres_version = get_postgres_version()
    if postgres_version:
        subject = "PostgreSQL Version from RDS"
        body = f"The version of PostgreSQL running on the RDS instance is: {postgres_version}"
        recipient_email = 'arunsnmimt@gmail.com'
        
        send_email_ses(subject, body, recipient_email)
    else:
        print("Could not fetch PostgreSQL version.")
