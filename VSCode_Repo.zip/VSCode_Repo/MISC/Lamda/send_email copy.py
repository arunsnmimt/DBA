import psycopg2
import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# Connect to PostgreSQL RDS
def get_postgres_version():
    try:
        connection = psycopg2.connect(
            host='database-2.cxoolvpkjide.ap-south-1.rds.amazonaws.com',
            port='5432',
            database='postgres',
            user='postgres',
            password='Password01!'
        )
        cursor = connection.cursor()
        cursor.execute("SELECT version();")
        postgres_version = cursor.fetchone()[0]
        cursor.close()
        connection.close()
        return postgres_version
    except Exception as error:
        print(f"Error connecting to PostgreSQL: {error}")
        return None

# Send email using Amazon SES
def send_email_ses(subject, body, recipient_email):
    ses_client = boto3.client(
        'ses',
        region_name='ap-south-1',  # e.g., 'us-west-2'
        aws_access_key_id='AKIAWHHB7WNRNNX5NPCR',  # Replace with your Access Key ID
        aws_secret_access_key='g1FzCwzT+KV7/n+hqMa7CRRh7yEdNYXzwPAb19uu'  # Replace with your Secret Access Key
    )
    sender_email = 'arunsnmimt@gmail.com'
    
    try:
        response = ses_client.send_email(
            Source=sender_email,
            Destination={
                'ToAddresses': [
                    recipient_email,
                ],
            },
            Message={
                'Subject': {
                    'Data': subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': body,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        print("Email sent! Message ID:", response['MessageId'])
    except (NoCredentialsError, PartialCredentialsError) as e:
        print("AWS Credentials Error:", e)
    except Exception as e:
        print(f"Error sending email: {e}")

# Main logic
if __name__ == '__main__':
    postgres_version = get_postgres_version()
    if postgres_version:
        subject = "PostgreSQL Version from RDS"
        body = f"The version of PostgreSQL running on the RDS instance is: {postgres_version}"
        recipient_email = 'arunsnmimt@gmail.com'
        
        send_email_ses(subject, body, recipient_email)
    else:
        print("Could not fetch PostgreSQL version.")
