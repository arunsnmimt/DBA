import os
import psycopg2
import configparser
import pandas as pd

def fetch_role_info(connection_string):
    conn = psycopg2.connect(connection_string)
    cursor = conn.cursor()
    cursor.execute("""
  with cte as  (
 SELECT 
            r.rolname AS role_name,
            c.description AS role_comment,
            array_agg(m.roleid::regrole) AS associated_roles
        FROM 
            pg_catalog.pg_roles r  
        LEFT JOIN 
            pg_shdescription c ON c.objoid = r.oid
        LEFT JOIN 
            pg_auth_members m ON m.member = r.oid
          
        GROUP BY 
            r.rolname, c.description)
            
            select * from cte where role_name not like 'pg%' and role_name not like 'rds%' and role_name not like 'read%' 
            and role_name not like '%smoss%' 
            
    """)
    role_info = cursor.fetchall()
    cursor.close()
    conn.close()
    return role_info

def main():
    # Hardcoded path to the config.ini file
    config_file_path = r'C:\connections\config-non-prod.ini'

    # Parse the configuration file
    config = configparser.ConfigParser()
    config.read(config_file_path)

    # Create an empty DataFrame to store role information
    df = pd.DataFrame(columns=['Instance', 'Role Name', 'Role Comment', 'Associated Roles'])

    # Fetch role information for each instance
    for section in config.sections():
        connection_string = config[section]['connection_string']
        instance_name = config[section]['instance_name']

        # Fetch role information
        role_info = fetch_role_info(connection_string)

        # Create a DataFrame for the current instance's role information
        df_instance = pd.DataFrame(columns=['Instance', 'Role Name', 'Role Comment', 'Associated Roles'])

        # Append fetched data to DataFrame
        for role_name, role_comment, associated_roles in role_info:
            df_instance = pd.concat([df_instance, pd.DataFrame({'Instance': instance_name, 'Role Name': role_name, 'Role Comment': role_comment, 'Associated Roles': ', '.join(associated_roles) if associated_roles else None}, index=[0])], ignore_index=True)

        # Concatenate the DataFrame for the current instance with the main DataFrame
        df = pd.concat([df, df_instance], ignore_index=True)

    # Write DataFrame to Excel
    output_file_path = r'C:\backup\role_info_report_non_prod_2024_04.xlsx'
    df.to_excel(output_file_path, index=False)
    print(f"Excel report saved to {output_file_path}")

if __name__ == "__main__":
    main()
