import os

# Define the directory
directory = 'C:\\text1'

# Iterate over all files in the directory
for filename in os.listdir(directory):
    # Construct the full file path
    file_path = os.path.join(directory, filename)
    
    # Check if it is a file (not a directory)
    if os.path.isfile(file_path):
        try:
            # Construct the new file name by appending .txt
            new_file_path = os.path.join(directory, f"{filename}.txt")
            
            # Rename the file
            os.rename(file_path, new_file_path)
        
        except Exception as e:
            # Print the error and continue with the next file
            print(f"Error renaming file {filename}: {e}")

print("Renaming complete.")
