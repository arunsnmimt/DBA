import configparser
import psycopg2
import os
import time
import pandas as pd
import json
from tqdm import tqdm  # For progress bar

config_file = r'C:\temp\config_table_copy.ini'

def load_config(config_file):
    config = configparser.ConfigParser()
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"The configuration file {config_file} does not exist.")
    config.read(config_file)
    
    # Ensure required sections exist
    required_sections = ['source', 'destination', 'switches']
    for section in required_sections:
        if section not in config:
            raise KeyError(f"The required section '{section}' is missing from the configuration file.")
    
    return config

# Create connection to PostgreSQL
def connect_db(host, port, database, user, password):
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        return conn
    except Exception as e:
        print(f"Error connecting to the database: {e}")
        return None

# Check if table exists in the destination schema
def table_exists(conn, schema, table):
    cursor = conn.cursor()
    query = f"""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = '{schema}' 
            AND table_name = '{table}'
        );
    """
    cursor.execute(query)
    exists = cursor.fetchone()[0]
    cursor.close()
    return exists

# Fetch all constraints (PK, FK, unique, and check)
def fetch_constraints(conn, schema, table):
    constraints_query = f"""
    SELECT
        conname,
        contype,
        pg_get_constraintdef(c.oid)
    FROM
        pg_constraint c
    JOIN
        pg_namespace n ON n.oid = c.connamespace
    WHERE
        conrelid = (
            SELECT oid
            FROM pg_class
            WHERE relname = '{table}' AND relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = '{schema}')
        );
    """
    cursor = conn.cursor()
    cursor.execute(constraints_query)
    constraints = cursor.fetchall()
    cursor.close()
    return constraints

# Fetch all indexes for the table
def fetch_indexes(conn, schema, table):
    indexes_query = f"""
    SELECT indexname, indexdef
    FROM pg_indexes
    WHERE schemaname = '{schema}' AND tablename = '{table}';
    """
    cursor = conn.cursor()
    cursor.execute(indexes_query)
    indexes = cursor.fetchall()
    cursor.close()
    return indexes

def generate_create_table_script(source_conn, source_schema, table):
    cursor = source_conn.cursor()
    cursor.execute(f"""
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_schema = '{source_schema}' AND table_name = '{table}';
    """)
    columns = cursor.fetchall()

    cursor.execute(f"""
        SELECT column_name
        FROM information_schema.key_column_usage
        WHERE table_schema = '{source_schema}' AND table_name = '{table}' AND constraint_name LIKE '%_pkey';
    """)
    primary_key = cursor.fetchone()
    
    create_table_script = f"CREATE TABLE {table} (\n"
    
    for column in columns:
        column_name, data_type, is_nullable = column
        nullable_str = "NOT NULL" if is_nullable == 'NO' else ""
        create_table_script += f"    {column_name} {data_type} {nullable_str},\n"
    
    # Add PRIMARY KEY clause if a primary key exists
    if primary_key:
        primary_key_column = primary_key[0]
        create_table_script += f"    PRIMARY KEY ({primary_key_column})\n"

    create_table_script = create_table_script.rstrip(",\n") + "\n);"  # Ensure proper ending
    cursor.close()
    return create_table_script

# Generate insert script
def generate_insert_script(source_conn, source_schema, table):
    cursor = source_conn.cursor()
    cursor.execute(f'SELECT * FROM "{source_schema}"."{table}"')
    
    columns = [desc[0] for desc in cursor.description]
    column_names = ', '.join(columns)
    
    # Initialize insert script
    insert_script = f"INSERT INTO {source_schema}.{table} ({column_names}) VALUES\n"
    
    rows = cursor.fetchall()
    value_lines = []
    
    # Prepare values for insertion
    for row in rows:
        formatted_values = []
        for value in row:
            if value is None:
                formatted_values.append('NULL')
            elif isinstance(value, str):
                # Escape single quotes in strings
                formatted_values.append(f"'{value.replace('\'', '\'\'')}'")
            elif isinstance(value, (int, float)):
                formatted_values.append(str(value))
            elif isinstance(value, bool):
                formatted_values.append('TRUE' if value else 'FALSE')
            else:
                # Handle other data types
                formatted_values.append(f"'{str(value).replace('\'', '\'\'')}'")
        
        value_lines.append(f"({', '.join(formatted_values)})")
    
    # Join all value lines
    insert_script += ',\n'.join(value_lines) + ";\n"
    
    cursor.close()
    return insert_script



def copy_table(source_conn, dest_conn, source_schema, dest_schema, table, truncate, batch_size, validate):
    start_time = time.time()
    
    try:
        # Check if the table exists in the destination
        table_exists_in_dest = table_exists(dest_conn, dest_schema, table)
        
        if validate and not table_exists_in_dest:
            # Generate and execute CREATE TABLE script if table doesn't exist
            create_table_script = generate_create_table_script(source_conn, source_schema, table)
            with open(f"C:\\temp\\create_{table}.sql", 'w') as f:
                f.write(create_table_script)
            
            cursor = dest_conn.cursor()
            cursor.execute(create_table_script)
            dest_conn.commit()
            cursor.close()
            print(f"Table {dest_schema}.{table} created in destination.")

        if not validate or (validate and table_exists_in_dest):
            # Optionally truncate the destination table
            if truncate:
                cursor = dest_conn.cursor()
                cursor.execute(f'TRUNCATE TABLE "{dest_schema}"."{table}" RESTART IDENTITY CASCADE;')
                dest_conn.commit()
                cursor.close()
                print(f"Truncated table {dest_schema}.{table}")

            # Copy data in batches
            src_cursor = source_conn.cursor()
            dest_cursor = dest_conn.cursor()
            
            src_cursor.execute(f'SELECT COUNT(*) FROM "{source_schema}"."{table}"')
            total_rows = src_cursor.fetchone()[0]
            
            src_cursor.execute(f'SELECT * FROM "{source_schema}"."{table}"')
            columns = [desc[0] for desc in src_cursor.description]  # Column names
            
            with tqdm(total=total_rows, unit='rows', desc=f'Copying {table}') as pbar:
                while True:
                    rows = src_cursor.fetchmany(batch_size)
                    if not rows:
                        break

                    # Convert any dictionary types to JSON before insertion
                    formatted_rows = [
                        [json.dumps(item) if isinstance(item, dict) else item for item in row]
                        for row in rows
                    ]
                    
                    dest_cursor.executemany(
                        f'INSERT INTO "{dest_schema}"."{table}" ({", ".join(columns)}) VALUES ({", ".join(["%s"] * len(columns))})',
                        formatted_rows
                    )
                    dest_conn.commit()
                    pbar.update(len(rows))

            src_cursor.close()
            dest_cursor.close()

        # Perform SELECT COUNT after the copy
        src_cursor = source_conn.cursor()
        dest_cursor = dest_conn.cursor()
        
        src_cursor.execute(f'SELECT COUNT(*) FROM "{source_schema}"."{table}"')
        source_row_count = src_cursor.fetchone()[0]
        
        dest_cursor.execute(f'SELECT COUNT(*) FROM "{dest_schema}"."{table}"')
        dest_row_count = dest_cursor.fetchone()[0]
        
        src_cursor.close()
        dest_cursor.close()

        end_time = time.time()
        return table, round(end_time - start_time, 2), "Success", source_row_count, dest_row_count  # Return row counts

    except Exception as e:
        end_time = time.time()
        error_msg = f"Error copying table {table}: {str(e)}"
        print(error_msg)
        return table, round(end_time - start_time, 2), error_msg, None, None  # Return row counts as None on error

def copy_data_and_generate_report(config):
    # Connect to source and destination databases
    source_conn = connect_db(
        config['source']['host'],
        config['source']['port'],
        config['source']['database'],
        config['source']['user'],
        config['source']['password']
    )
    
    dest_conn = connect_db(
        config['destination']['host'],
        config['destination']['port'],
        config['destination']['database'],
        config['destination']['user'],
        config['destination']['password']
    )
    
    source_schema = config['source']['schema']
    dest_schema = config['destination']['schema']
    
    truncate = config['switches'].getboolean('truncate')
    batch_size = int(config['switches'].get('batch_size', 1000))
    table_names = config['switches']['table_names'].split(',')
    validate = config['switches'].getboolean('validate')
    only_generate_inserts = config['switches'].getboolean('only_generate_inserts')

    # Sequentially process each table
    report_data = []
    for table in table_names:
        if only_generate_inserts:
            # Generate and save insert script only
            insert_script = generate_insert_script(source_conn, source_schema, table)
            with open(f"C:\\temp\\insert_{table}.sql", 'w', encoding='utf-8') as f:
                f.write(insert_script)
            print(f"Insert script for table {table} saved.")
            report_data.append((table, 'N/A', 'Insert script generated only', None, None))
        else:
            # Copy table and generate report
            table_name, time_taken, status, source_row_count, dest_row_count = copy_table(
                source_conn, dest_conn, source_schema, dest_schema, table, truncate, batch_size, validate
            )
            report_data.append((table_name, time_taken, status, source_row_count, dest_row_count))

    # Generate and save HTML report
    generate_html_report(report_data, "C:\\temp\\row_count_comparison_report.html")


def generate_html_report(report_data, output_path):
    html_content = """
    <html>
    <head>
        <title>Row Count Comparison Report</title>
    </head>
    <body>
        <h1>Row Count Comparison Report</h1>
        <table border="1">
            <tr>
                <th>Table</th>
                <th>Time Taken (s)</th>
                <th>Source Row Count</th>
                <th>Destination Row Count</th>
                <th>Status</th>
            </tr>
    """
    for table, time_taken, status, source_row_count, dest_row_count in report_data:
        html_content += f"""
            <tr>
                <td>{table}</td>
                <td>{time_taken}</td>
                <td>{source_row_count if source_row_count is not None else 'N/A'}</td>
                <td>{dest_row_count if dest_row_count is not None else 'N/A'}</td>
                <td>{status}</td>
            </tr>
        """
    html_content += """
        </table>
    </body>
    </html>
    """

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"Report saved to {output_path}")

if __name__ == "__main__":
    config = load_config(config_file)
    copy_data_and_generate_report(config)
