import psycopg2
from sqlalchemy import create_engine
import pandas as pd
import json

# Define the database connection details
DATABASE_URL = "postgresql+psycopg2://postgres:postgres@localhost:5432/DBA"

# Create an engine and connect to the database
engine = create_engine(DATABASE_URL)
connection = engine.connect()

# Query to get foreign key relationships for the specified schema
query = """
SELECT 
    tc.table_name AS referencing_table, 
    kcu.column_name AS referencing_column, 
    ccu.table_name AS referenced_table, 
    ccu.column_name AS referenced_column
FROM 
    information_schema.table_constraints AS tc 
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
WHERE 
    tc.constraint_schema = 'smms_customerportal_v2' AND
    constraint_type = 'FOREIGN KEY'
ORDER BY 
    tc.table_name, kcu.column_name;
"""

# Execute the query and fetch the results into a DataFrame
foreign_keys_df = pd.read_sql(query, connection)

# Close the database connection
connection.close()

# Prepare JSON data for D3.js
nodes = set(foreign_keys_df['referencing_table']).union(set(foreign_keys_df['referenced_table']))
links = [{"source": row['referencing_table'], 
          "target": row['referenced_table'], 
          "relation": f"{row['referencing_column']} -> {row['referenced_column']}",
          "source_column": row['referencing_column']}  # Add source column for color mapping
         for index, row in foreign_keys_df.iterrows()]

data = {
    "nodes": [{"id": node} for node in nodes],
    "links": links
}

# Save JSON data to file in the static directory
json_data = json.dumps(data)

# Save the HTML file with embedded data
html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Foreign Key Relationships</title>
    <style>
        .link {{
            stroke: #999;
            stroke-opacity: 0.6;
        }}
        
        .node {{
            cursor: move;
            stroke: #fff;
            stroke-width: 1.5px;
        }}

        .node text {{
            font-family: Arial, sans-serif;
            font-size: 12px;
            text-anchor: middle;
        }}

        .node.cyan {{
            fill: cyan;
        }}

        .node.orange {{
            fill: orange;
        }}

        .node.purple {{
            fill: purple;
        }}

        .node.green {{
            fill: green;
        }}

        .node.red {{
            fill: red;
        }}

        .arrowhead {{
            fill: #999;
        }}
    </style>
</head>
<body>
    <svg width="1500" height="1200"></svg>
    <script src="https://d3js.org/d3.v6.min.js"></script>
    <script>
        const data = {json_data};

        const svg = d3.select("svg");

        // Define arrow markers
        svg.append("defs").selectAll("marker")
            .data(["arrow"])
            .enter().append("marker")
            .attr("id", "arrow")
            .attr("viewBox", "0 -5 10 10")
            .attr("refX", 20)  // Controls the position of the arrowhead
            .attr("refY", 0)
            .attr("markerWidth", 6)
            .attr("markerHeight", 6)
            .attr("orient", "auto")
            .append("path")
            .attr("class", "arrowhead")
            .attr("d", "M0,-5L10,0L0,5");

        const simulation = d3.forceSimulation(data.nodes)
            .force("link", d3.forceLink(data.links).id(d => d.id).distance(100))  // Increase distance to avoid overlapping
            .force("charge", d3.forceManyBody().strength(-200))
            .force("center", d3.forceCenter(400, 300))
            .force("collision", d3.forceCollide().radius(20));  // Collision detection to prevent overlapping

        const link = svg.append("g")
            .attr("class", "links")
            .selectAll("line")
            .data(data.links)
            .enter().append("line")
            .attr("class", "link")
            .attr("marker-end", "url(#arrow)");  // Attach arrowhead to the end of the line

        link.append("title")
            .text(d => d.relation);

        const node = svg.append("g")
            .attr("class", "nodes")
            .selectAll("circle")
            .data(data.nodes)
            .enter().append("circle")
            .attr("class", d => "node " + getColorClass(d.id))  // Apply color class based on node ID
            .attr("r", 10)
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        node.append("title")
            .text(d => d.id);

        const text = svg.append("g")
            .attr("class", "texts")
            .selectAll("text")
            .data(data.nodes)
            .enter().append("text")
            .attr("x", 12)
            .attr("y", ".31em")
            .text(d => d.id);

        simulation.on("tick", () => {{
            link
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);

            node
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);

            text
                .attr("x", d => d.x + 12)
                .attr("y", d => d.y + 3);
        }});

        function getColorClass(nodeId) {{
            switch (nodeId) {{
                case "{nodes.pop()}":
                    return "cyan";
                case "{nodes.pop()}":
                    return "orange";
                case "{nodes.pop()}":
                    return "purple";
                case "{nodes.pop()}":
                    return "green";
                case "{nodes.pop()}":
                    return "red";
                default:
                    return "cyan";
            }}
        }}

        function dragstarted(event, d) {{
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }}

        function dragged(event, d) {{
            d.fx = event.x;
            d.fy = event.y;
        }}

        function dragended(event, d) {{
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }}
    </script>
</body>
</html>
"""

# Save the HTML content to a file
output_path = 'C:\\backup\\fk_diagram.html'
with open(output_path, 'w') as f:
    f.write(html_content)

print(f"HTML file saved to {output_path}")