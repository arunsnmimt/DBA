import os
import re
import psycopg2
from collections import defaultdict

# Base path to the folder containing market subfolders
base_path = r"C:\Release scripts\R5_PROD\SMOSS-DB-Scripts-releases\CR\PROD_Scripts"

# Regular expression to match function definitions (captures name and parameters)
function_regex = re.compile(
    r'CREATE (OR REPLACE )?FUNCTION\s+([\w.]+)\s*\((.*?)\)',  # Optional OR REPLACE
    re.IGNORECASE | re.DOTALL,
)

# Query to fetch specific functions from the database
FETCH_SPECIFIC_FUNCTION_QUERY = """
SELECT pg_get_functiondef(p.oid)
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE p.proname = ANY(%s);
"""

# Dictionary to store functions by market
market_functions = defaultdict(list)

# Directory for rollback files
rollback_base_path = r"C:\Release scripts\R5\SMOSS-DB-Scripts-releases\CR\PROD_Scripts"

# Iterate through the market folders (e.g., AU, IN, MY)
for market_folder in os.listdir(base_path):
    market_path = os.path.join(base_path, market_folder)
    if os.path.isdir(market_path):  # Ensure it's a folder
        # Iterate through the market's subfolders (e.g., adminportal, customerportal)
        for root, dirs, files in os.walk(market_path):
            # Skip 'Rollback' subfolders at any level
            if 'Rollback' in dirs:
                dirs.remove('Rollback')  # Prevent traversal into 'Rollback'

            for file in files:
                # Ignore files with a '_combined' prefix
                if file.startswith("_combined"):
                    continue
                if file.endswith(".sql"):  # Only process SQL files
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Find the first function definition in the file
                        match = function_regex.search(content)
                        if match:
                            function_name = match[2]  # Extract function name
                            parameters = match[3].strip()  # Extract parameter list
                            function_signature = f"{function_name}({parameters})"
                            
                            # Add the function signature to the market
                            market_functions[market_folder].append(function_name)

# Function to fetch specific functions from the database based on function names
def fetch_functions(connection_string, function_names, schema_name):
    if not function_names:  # Skip if no function names are found
        print("No function names found. Skipping database fetch.")
        return []

    print(f"Connecting to database for schema '{schema_name}' and functions: {function_names}")

    try:
        with psycopg2.connect(connection_string) as conn:
            with conn.cursor() as cur:
                # Set schema search path to the specific schema
                cur.execute(f"SET search_path TO {schema_name};")
                print(f"Successfully connected to the database: {connection_string.split()[0]}")  # Log DB connection

                # Prepare query and fetch function definitions by function name (ignoring schema prefix)
                cur.execute(FETCH_SPECIFIC_FUNCTION_QUERY, (list(function_names),))
                return cur.fetchall()
    except Exception as e:
        print(f"Error fetching functions from the database: {e}")
        return []

# Read connection details and fetch functions for each market
connections = {
    "AU": "dbname=smoss_AU user=qxz4scs password=Welcome2bmw2023 host=localhost port=7150",
    "AU_MINI": "dbname=smoss_au_mini user=qxz4scs password=Welcome2bmw2023 host=localhost port=7150",
    "IN": "dbname=smoss_IN user=qxz4scs password=Welcome2bmw2023 host=localhost port=7160",
    "NZ": "dbname=smoss_NZ user=qxz4scs password=Welcome2bmw2023 host=localhost port=7190",
    "MY": "dbname=smoss_MY user=qxz4scs password=Welcome2bmw2023 host=localhost port=7130",
    "TH": "dbname=smoss_TH user=qxz4scs password=Welcome2bmw2023 host=localhost port=7130",
}

# Fetch functions from the database for each market
for market, functions in market_functions.items():
    print(f"\nMarket: {market}")
    print(f"  Total Functions in Files: {len(functions)}")
    print(f"  Function Names: {functions}")

    # Fetch functions for the market, using the correct schema context
    if functions:
        print(f"Fetching the following functions: {functions}")
        if market in connections:
            for function in functions:
                # Extract the schema from the function name (prefix before the dot)
                schema_name = function.split('.')[0]

                # Use the schema context to connect and fetch the function without the schema prefix
                fetched_functions = fetch_functions(connections[market], [function.split('.')[1]], schema_name)
                if fetched_functions:
                    for func_def in fetched_functions:
                        func_name = function.split('.')[1]
                        print(f"  Saving function {func_name} to the rollback folder")

                        # Determine the correct rollback folder path based on the schema prefix
                        if schema_name.startswith('bmw_admin'):  # Check if function belongs to admin portal
                            rollback_folder_path = os.path.join(
                                rollback_base_path, market, "adminportal", "Rollback"
                            )
                        elif schema_name.startswith('smms_customerportal'):  # Check if function belongs to customer portal
                            rollback_folder_path = os.path.join(
                                rollback_base_path, market, "customerportal", "Rollback"
                            )
                        else:
                            print(f"Unknown schema for function {func_name}, skipping.")
                            continue
                        
                        # Create a directory for the rollback folder if it doesn't exist
                        os.makedirs(rollback_folder_path, exist_ok=True)

                        # Save the function to the appropriate rollback folder
                        rollback_file_path = os.path.join(rollback_folder_path, f"{func_name}.sql")
                        with open(rollback_file_path, 'w', encoding='utf-8') as f:
                            f.write(func_def[0])  # Writing the function definition

                    print(f"  Total Functions Saved: {len(fetched_functions)}")
                else:
                    print(f"  No functions fetched for {function}.")
