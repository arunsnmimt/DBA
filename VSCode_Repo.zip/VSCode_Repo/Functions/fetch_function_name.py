import os
import re
import psycopg2
from collections import defaultdict

# Base path to the folder containing market subfolders
base_path = r"C:\Release scripts\R5_PROD\SMOSS-DB-Scripts-releases\CR\PROD_Scripts"

# Regular expression to match function definitions (captures name and parameters)
function_regex = re.compile(
    r'CREATE (OR REPLACE )?FUNCTION\s+([\w.]+)\s*\((.*?)\)',  # Optional OR REPLACE
    re.IGNORECASE | re.DOTALL,
)

# Query to fetch specific functions from the database
FETCH_SPECIFIC_FUNCTION_QUERY = """
SELECT pg_get_functiondef(p.oid)
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE p.proname = ANY(%s);
"""

# Dictionary to store functions by market
market_functions = defaultdict(list)

# Iterate through the market folders (e.g., AU, IN, MY)
for market_folder in os.listdir(base_path):
    market_path = os.path.join(base_path, market_folder)
    if os.path.isdir(market_path):  # Ensure it's a folder
        # Iterate through the market's subfolders (e.g., adminportal, customerportal)
        for root, dirs, files in os.walk(market_path):
            # Skip 'Rollback' subfolders at any level
            if 'Rollback' in dirs:
                dirs.remove('Rollback')  # Prevent traversal into 'Rollback'

            for file in files:
                # Ignore files with a '_combined' prefix
                if file.startswith("_combined"):
                    continue
                if file.endswith(".sql"):  # Only process SQL files
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Find the first function definition in the file
                        match = function_regex.search(content)
                        if match:
                            function_name = match[2]  # Extract function name
                            parameters = match[3].strip()  # Extract parameter list
                            function_signature = f"{function_name}({parameters})"
                            
                            # Add the function signature to the market
                            market_functions[market_folder].append(function_name)

# Function to fetch specific functions from the database
def fetch_functions(connection_string, function_names):
    if not function_names:  # Skip if no function names are found
        print("No function names found. Skipping database fetch.")
        return []

    try:
        with psycopg2.connect(connection_string) as conn:
            with conn.cursor() as cur:
                # Prepare query and fetch function definitions
                cur.execute(FETCH_SPECIFIC_FUNCTION_QUERY, (list(function_names),))
                return cur.fetchall()
    except Exception as e:
        print(f"Error fetching functions: {e}")
        return []

# Read connection details and fetch functions for each market
connections = {
    "AU": "dbname=smoss_AU user=qxz4scs password=Welcome2bmw2023 host=localhost port=7150",
    "AU_MINI": "dbname=smoss_au_mini user=qxz4scs password=Welcome2bmw2023 host=localhost port=7150"
}

# Fetch functions from the database
for market, functions in market_functions.items():
    print(f"\nMarket: {market}")
    print(f"  Total Functions in Files: {len(functions)}")
    
    if market in connections:
        fetched_functions = fetch_functions(connections[market], functions)
        if fetched_functions:
            print(f"  Total Functions Fetched from Database: {len(fetched_functions)}")
        else:
            print("  No functions fetched from the database.")
    else:
        print("  No database connection configured for this market.")
