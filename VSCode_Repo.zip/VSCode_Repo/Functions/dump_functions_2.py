import os
import psycopg2

def fetch_function_code(database_name, schema_name, user, password, host, port, function_names, output_directory):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    for function_name in function_names:
        sql_query = f"""
            SELECT pg_get_functiondef((SELECT oid FROM pg_proc WHERE proname = '{function_name}' AND pronamespace = (SELECT oid FROM pg_namespace WHERE nspname = '{schema_name}')))
        """
        print("Executing SQL query:", sql_query)
        cursor.execute(sql_query)
        code = cursor.fetchone()
        if code and code[0]:  # Check if code is not None and not an empty string
            print("Function code found for:", function_name)
            database_directory = os.path.join(output_directory, database_name)
            if not os.path.exists(database_directory):
                os.makedirs(database_directory)
            file_path = os.path.join(database_directory, f"{function_name}.sql")
            with open(file_path, 'w') as file:
                file.write(code[0])
                print("Function code written to file:", file_path)
        else:
            print("Function code not found for:", function_name)
    cursor.close()
    connection.close()

def main():
    database_name1 = "smoss_in"
    schema_name1 = "smms_customerportal_v2"
    user1 = "qxz4scs"
    password1 = "Welcome2bmw2023"
    host1 = "localhost"
    port1 = 8102

    # Second Database details
    database_name2 = "smoss_in"
    schema_name2 = "smms_customerportal_v2"
    user2 = "qxz4scs"
    password2 = "Welcome2bmw2023"
    host2 = "localhost"
    port2 = 8130 

    # Function names to fetch
    function_names = [
        "admin_keep_me_informed_oem",
        "admin_oem_payment_report_v1"
    ]

    # Output directory
    output_directory = r"C:\functions"

    # Fetch function code from the first server
    fetch_function_code(database_name1, schema_name1, user1, password1, host1, port1, function_names, output_directory)

    # Fetch function code from the second server
    fetch_function_code(database_name2, schema_name2, user2, password2, host2, port2, function_names, output_directory)

if __name__ == "__main__":
    main()
