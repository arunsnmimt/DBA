import os
import psycopg2

def fetch_function_code(database_name, schema_name, user, password, host, port, function_names, output_directory):
    connection = psycopg2.connect(
        dbname=database_name,
        user=user,
        password=password,
        host=host,
        port=port
    )
    cursor = connection.cursor()
    for function_name in function_names:
        cursor.execute(f"""
            SELECT pg_get_functiondef((SELECT oid FROM pg_proc WHERE proname = '{function_name}' AND pronamespace = (SELECT oid FROM pg_namespace WHERE nspname = '{schema_name}')))
        """)
        code = cursor.fetchone()
        if code and code[0]:  # Check if code is not None and not an empty string
            file_path = os.path.join(output_directory, f"{function_name}.sql")
            with open(file_path, 'w') as file:
                file.write(code[0])
    cursor.close()
    connection.close()

def main():
    # First Database details
    database_name1 = "smoss_th_Pre_Prod"
    schema_name1 = "bmw_admin_th"
    user1 = "qxz4scs"
    password1 = "Welcome2bmw2023"
    host1 = "localhost"
    port1 = 8102

    # Second Database details
    database_name2 = "smoss_th"
    schema_name2 = "bmw_admin_th"
    user2 = "qxz4scs"
    password2 = "Welcome2bmw2023"
    host2 = "localhost"
    port2 = 8120

    # Function names to fetch
    function_names = [
        "bmw_admin_th.backup_and_truncate_vss_master"
        ]

    # Output directory
    output_directory = r"C:\functions"

    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # Fetch function code from the first server
    fetch_function_code(database_name1, schema_name1, user1, password1, host1, port1, function_names, output_directory)

    # Fetch function code from the second server
    fetch_function_code(database_name2, schema_name2, user2, password2, host2, port2, function_names, output_directory)

if __name__ == "__main__":
    main()
