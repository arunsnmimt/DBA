import streamlit as st
from pathlib import Path
from langchain.agents import create_sql_agent
from langchain.sql_database import SQLDatabase
from langchain.agents.agent_types import AgentType
from langchain.callbacks import StreamlitCallbackHandler
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from sqlalchemy import create_engine
import psycopg2
from langchain_community.llms import Ollama  # Assuming Ollama integration

st.set_page_config(page_title="LangChain: Chat with SQL DB", page_icon="🦜")
st.title("🦜 LangChain: Chat with SQL DB")

POSTGRES = "USE_POSTGRES"

radio_opt = ["Use Postgres Database"]
selected_opt = st.sidebar.radio(label="Choose the DB which you want to chat", options=radio_opt)

if radio_opt.index(selected_opt) == 0:
    db_uri = POSTGRES
    pg_host = st.sidebar.text_input("Postgres Host", value="localhost")
    pg_port = st.sidebar.text_input("Postgres Port", value="5432")
    pg_user = st.sidebar.text_input("Postgres User")
    pg_password = st.sidebar.text_input("Postgres Password", type="password")
    pg_db = st.sidebar.text_input("Postgres Database")

api_key = st.sidebar.text_input(label="Ollama API Key", type="password")

if not db_uri:
    st.info("Please enter the database information and uri")

if not api_key:
    st.info("Please add the Ollama API key")

## LLM model
llm = Ollama(model="llama3.1")

@st.cache_resource(ttl="2h")
def configure_db(db_uri, pg_host=None, pg_port=None, pg_user=None, pg_password=None, pg_db=None):
    if db_uri == POSTGRES:
        if not (pg_host and pg_port and pg_user and pg_password and pg_db):
            st.error("Please provide all Postgres connection details.")
            st.stop()
        engine_url = f"postgresql+psycopg2://{pg_user}:{pg_password}@{pg_host}:{pg_port}/{pg_db}"
        return SQLDatabase(create_engine(engine_url))
    
db = configure_db(db_uri, pg_host, pg_port, pg_user, pg_password, pg_db)

## toolkit
toolkit = SQLDatabaseToolkit(db=db, llm=llm)

agent = create_sql_agent(
    llm=llm,
    toolkit=toolkit,
    verbose=True,
    agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION
)

if "messages" not in st.session_state or st.sidebar.button("Clear message history"):
    st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]

for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

user_query = st.chat_input(placeholder="Ask anything from the database")

if user_query:
    st.session_state.messages.append({"role": "user", "content": user_query})
    st.chat_message("user").write(user_query)

    with st.chat_message("assistant"):
        streamlit_callback = StreamlitCallbackHandler(st.container())
        response = agent.run(user_query, callbacks=[streamlit_callback])
        st.session_state.messages.append({"role": "assistant", "content": response})
        st.write(response)
