from sentence_transformers import SentenceTransformer
from sqlalchemy import create_engine, MetaData, text
import numpy as np
import faiss
import logging
from datetime import datetime, timedelta
import ollama  # Assuming ollama library is imported and set up correctly
import mesop as me  # Importing mesop as me

# Initialize logging
logging.basicConfig(level=logging.INFO)

# Initialize the model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Connect to PostgreSQL
engine = create_engine("postgresql+psycopg2://postgres:postgres@localhost:5432/Arun")

# Function to initialize components and handle errors
def initialize_components():
    try:
        # Connect to PostgreSQL
        conn = engine.connect()

        # Direct SQL query to list all tables in the schema
        query = text("SELECT table_name FROM information_schema.tables WHERE table_schema = 'smms_customerportal_v2'")
        result = conn.execute(query)
        table_names = [row[0] for row in result]

        # Reflect the metadata from the schema
        metadata = MetaData()
        metadata.reflect(bind=engine, schema="smms_customerportal_v2")

        # Initialize FAISS index
        embeddings = []
        table_name_map = {}

        for table_name in table_names:
            table = metadata.tables.get(table_name)
            if table is None:
                logging.warning(f"Table '{table_name}' not found in metadata. Skipping.")
                continue

            # Get keywords from the table name
            keywords = table_name.lower().split('_')

            # Generate schema text and encode with SentenceTransformer
            schema_text = f"Table: {table_name}, Keywords: {', '.join(keywords)}"

            try:
                embedding = model.encode(schema_text)
                embeddings.append(embedding)
                table_name_map[len(embeddings) - 1] = table_name  # Ensure indices match
            except Exception as e:
                logging.error(f"Error encoding table '{table_name}': {e}")
                continue  # Skip the table if an error occurs

        # If no embeddings were created, log and return
        if not embeddings:
            logging.error("No valid tables were processed for embedding.")
            return None, None, None, None

        # Convert embeddings to numpy array
        embeddings = np.array(embeddings).astype('float32')

        # Build FAISS index
        index = faiss.IndexFlatL2(embeddings.shape[1])
        index.add(embeddings)

        return conn, metadata, index, table_name_map

    except Exception as e:
        error_message = f"An error occurred during initialization: {e}"
        logging.error(error_message)
        raise

# Function to find the most similar table
def find_similar_table(query, index, model, table_name_map):
    try:
        query_embedding = model.encode(query.lower())

        if len(table_name_map) == 0:
            logging.error("No tables available for similarity search.")
            return None, None

        # Search using FAISS index
        D, I = index.search(np.array([query_embedding]), 1)
        
        if I[0][0] < 0:  # Check if a valid index is found
            logging.error("No similar table found.")
            return None, None

        closest_table_index = I[0][0]
        closest_table_name = table_name_map.get(closest_table_index, None)
        distance = D[0][0]

        return closest_table_name, distance

    except Exception as e:
        error_message = f"An error occurred during table search: {e}"
        logging.error(error_message)
        raise

# Initialize components
try:
    conn, metadata, index, table_name_map = initialize_components()

    if conn is None or index is None or table_name_map is None:
        logging.error("Failed to initialize components properly.")
    else:
        # Example usage with Ollama
        input_query = "retrieve customer details"
        closest_table_name, distance = find_similar_table(input_query, index, model, table_name_map)

        if closest_table_name:
            # Format response for chat output
            response = f"Based on your query '{input_query}', the most relevant table is '{closest_table_name}' with a similarity score of {1 - distance:.2f}."
            logging.info(response)

            # Simulate chat output with Ollama
            stream = ollama.chat(model='llama3', messages=[{"role": "user", "content": input_query}], stream=True)

            for chunk in stream:
                content = chunk.get('message', {}).get('content', '')
                if content:
                    logging.info(content)  # Display chat output from Ollama

            # Use mesop for additional functionality
            result = me.perform_action('sql_db_query', f"SELECT * FROM {closest_table_name} LIMIT 5")
            logging.info(result)  # Log mesop output
        else:
            logging.error("No relevant table found.")

except Exception as e:
    logging.error(f"Initialization failed: {e}")
