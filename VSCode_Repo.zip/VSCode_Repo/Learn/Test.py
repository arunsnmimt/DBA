name = "Guru Charanam Saranam"
print(name)
name.lower()
name.lower().upper





